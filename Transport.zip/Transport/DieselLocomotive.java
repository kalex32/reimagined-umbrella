package Transport;

class DieselLocomotive extends RollingStock {

    private double speedDieselLocomotive;

    DieselLocomotive(int carriageCount) {
        super(carriageCount);
        this.speedDieselLocomotive=85;
    }
}
