package Transport;

interface CarsMethods {

    int carsCountForPassengers(int passengerCount);

    int carsCountForBaggage(double baggageCount);
}
