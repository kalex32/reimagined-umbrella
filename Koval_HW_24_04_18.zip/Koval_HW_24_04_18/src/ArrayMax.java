import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class ArrayMax {

    public static void main(String[] args) {

        int[] array = new int[3];
        Random random=new Random ();
        //Scanner scanner = new Scanner (System.in);
        for (int i = 0; i < array.length; i++) {
           // array[i] = scanner.nextInt ( );
            array[i]= random.nextInt (100);
        }
        System.out.println (Arrays.toString (array));
        int index = 0;


        System.out.println (maxElement (array, index));



    }



    static int maxElement(int[] array, int index) {
        int arrayMax = array[index];
        while (index < array.length - 1) {
            index++;
            if (array[index] > arrayMax) {
                maxElement (array, index);
            }

        }
        return arrayMax;


    }


}





