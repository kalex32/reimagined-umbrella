import java.awt.*;

//public class Party {
    /*public void builinvite(){
        Frame f =new Frame ();
        Label 1=new Label ("Вечеринка у Тима");
        Button b = new Button ("Ваша ставка");
        Button c =new Button ("Сбросить");
        Panel p = new Panel ();
        p.add (l);
    }
}
*/