import java.util.Scanner;

public class Realis {
    /*static double scanner1() {
        Scanner scan = new Scanner (System.in);
        double a = scan.nextDouble ( );
        return a;

    }

    static int scanner() {
        Scanner scan = new Scanner (System.in);
        while (!scan.hasNextInt ( )) {
            System.out.println ("Неправильный ввод! Введите целое число!");
            scan.nextInt ( );
        }
        int n = scan.nextInt ( );
        return n;
    }


    static int counter() {
        int count = 2;
        return count;
    }
*/


    private static void degree(double a, int n, int count, double result) {
        if (n == 1) {
            System.out.println ("Число в степени 1 равно самому себе: " + a);
        } else if (count < n) {
            result = result * a;
            count++;
            degree (a, n, count, result);
        } else if (count == n) {
            System.out.println (result);
            return;
        }

    }

    public static void main(String[] args) {

       // degree (scanner1 ( ), scanner ( ), counter ( ), 7 );
        degree(2, 8, 2, 2);

    }


}




