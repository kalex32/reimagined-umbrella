import java.util.ArrayList;
import java.util.Scanner;

public class PopularLetter {
    // Дан текст, который содержит различные английские буквы и знаки препинания.
    // Вам необходимо найти самую частую букву в тексте.
    // Результатом должна быть буква в нижнем регистре.

    public static void main(String[] args) {
        System.out.println("Введите текст на английском языке:");
        Scanner scanner = new Scanner(System.in);
        String text = scanner.nextLine();
        scanner.close();

        String lowerText = text.toLowerCase();
        char[] letter = lowerText.toCharArray();
        System.out.println(letter);

        ArrayList<Character> letterList = new ArrayList<>();
        for (int i = 0; i < letter.length; i++) {
            if (letter[i]>='a'&&letter[i]<='z'){
                letterList.add(letter[i]);
            }
        }
//        System.out.println(letterList);
//        char[] letter1=letterList.toArray(new char[]);
//        System.out.println(letterList);
    }
}
