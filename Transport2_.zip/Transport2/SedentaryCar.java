package Transport2;

class SedentaryCar extends RollingStock{

    SedentaryCar(){

        super();
        setAmountOfPassengersCar(90);
        setBaggageWeight(3300.0);
        setComfortClassCar(4);
        setNameCar("Сидячий вагон");
    }
}
