package Transport2;

interface Train {

    int countOfPassengersTrain(RollingStock[] train);
    double countOfBaggageTrain(RollingStock[] train);
}
