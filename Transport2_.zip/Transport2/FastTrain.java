package Transport2;

import java.util.Arrays;

class FastTrain implements Train {

    private String nameOfTrain;

    FastTrain() {
        this.nameOfTrain = "Скорый поезд";

    }

    RollingStock[] fastTrain = {
            new Coupe(),
            new SleepingCar(),
            new SedentaryCar(),
            new SedentaryCar(),
            new CouchetteCar(),
            new CouchetteCar(),
            new Coupe(),
            new Coupe(),
            new SleepingCar(),
            new Coupe()
    };

//    void sorting(RollingStock[] fastTrain){
//        Arrays.sort(fastTrain);
//        //sorting(fastTrain);
//        for (int i = 0; i < fastTrain.length; i++) {
//            System.out.println(fastTrain[i].getComfortClassCar());
//
//        }
//    }


    String getNameOfTrain() {
        return nameOfTrain;
    }


    @Override
    public int countOfPassengersTrain(RollingStock[] fastTrain) {
        int countOfPassengers = 0;
        for (int i = 0; i < fastTrain.length; i++) countOfPassengers += fastTrain[i].getAmountOfPassengersCar();
        return countOfPassengers;
    }

    @Override
    public double countOfBaggageTrain(RollingStock[] fastTrain) {
        int countOfBaggage = 0;
        for (int i = 0; i < fastTrain.length; i++) countOfBaggage += fastTrain[i].getBaggageWeight();
        return countOfBaggage;
    }

}
