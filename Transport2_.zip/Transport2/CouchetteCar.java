package Transport2;

class CouchetteCar extends RollingStock {

    CouchetteCar() {
        super();
        setAmountOfPassengersCar(54);
        setBaggageWeight(1900.0);
        setComfortClassCar(3);
        setNameCar("Плацкартный вагон");
    }
}
