package DZ2_Inheritance.Fauna;

class Mammalian extends Eating {
    String animal;

    Mammalian() {
        this.animal = "animal";
    }

    void dif(){
        System.out.println("Mammals are different.");
    }
}