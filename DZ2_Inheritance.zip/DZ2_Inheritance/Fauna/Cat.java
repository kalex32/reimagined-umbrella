package DZ2_Inheritance.Fauna;

class Cat extends DomesticAnimal {

    Cat(String animal, String name) {
        super();
    }
}
