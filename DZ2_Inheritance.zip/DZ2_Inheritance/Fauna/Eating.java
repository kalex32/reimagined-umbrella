package DZ2_Inheritance.Fauna;

class Eating {

    Eating() {
    }

    void eat(Object animal, String food) {

        System.out.println(animal + " eating " + food);
    }
}
