package DZ2_Inheritance.Fauna;

class Pike extends Fish {
    String name;

    Pike() {
        super();
        this.name="pike";
    }
}
