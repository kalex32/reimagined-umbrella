package DZ2_Inheritance.Fauna;

class Dog extends DomesticAnimal {

    Dog(String animal, String name) {
        super();
    }
}
