package DZ2_Inheritance.Fauna;

class Goldfish extends Fish {
    String name;

    Goldfish() {
        super();
        this.name="goldfish";
    }
}
