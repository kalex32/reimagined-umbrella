public class Main {
    Main p = new Main ();

}