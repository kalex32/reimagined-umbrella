public class Square extends Rectangle {
    private double side; // сторона квадрата

    @Override
    public double getWidth() {
        return super.getWidth ( );
    }

    @Override
    public double getHeight() {
        return super.getHeight ( );
    }

    public static Square getInstance() {
        return Rectangle;
    }

    public Square(String name, double side){
        super(name);
        this.side=side;

    }


}
