package Transport2;

class SleepingCar extends RollingStock{

    SleepingCar() {
        super();
        setAmountOfPassengersCar(18);
        setBaggageWeight(650.0);
        setComfortClassCar(1);
        setNameCar("СВ");
    }


}
