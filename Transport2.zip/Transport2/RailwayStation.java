package Transport2;

import java.util.Arrays;

class RailwayStation {
    // Транспорт. Определить иерархию подвижного состава железнодорожного транспорта.
    // Создать пассажирский поезд. Подсчитать общую численность пассажиров и багажа.
    // Провести сортировку вагонов поезда на основе уровня комфортности.
    // Найти в поезде вагоны, соответствующие заданному диапазону параметров числа пассажиров.

    public static void main(String[] args) {
        SleepingCar sleepingCar = new SleepingCar();
        FastTrain[] fastTrains = new FastTrain[][2];
              fastTrains[0]=  ;
                new Coupe()


        System.out.println("Колличество пассажиров в "+fastTrain.getNameOfTrain()+": "+fastTrain.countOfPassengersTrain());
        System.out.println(Arrays.toString(new FastTrain[]{fastTrain}));
    }
}
