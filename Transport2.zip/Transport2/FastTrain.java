package Transport2;

class FastTrain implements Train {

    private String nameOfTrain;
    // private Train[] fastTrain;

    FastTrain() {
        this.nameOfTrain = "Скорый поезд";
    }

    String getNameOfTrain() {
        return nameOfTrain;
    }


    @Override
    public int countOfPassengersTrain(SleepingCar sleepingCar, Coupe coupe) {
        return (sleepingCar.getAmountOfPassengersCar())*2 + coupe.getAmountOfPassengersCar();
    }
}
