package Transport2;

interface Train <T>{

    int countOfPassengersTrain(SleepingCar sleepingCar, Coupe coupe);
}
