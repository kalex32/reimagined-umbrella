package Transport2;

class Coupe extends RollingStock {

    Coupe() {
        super();
        setAmountOfPassengersCar(38);
        setBaggageWeight(1400.0);
        setComfortClassCar(2);
        setNameCar("Купейный вагон");
    }
}
