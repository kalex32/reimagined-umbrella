package DZ1_Inheritance;

class Rectangle extends Shape {
    Rectangle(double width, double height) {
        super(width, height);
    }

    boolean isSquare() {
        return (getWidth() == getHeight());
    }

    double area() {
        return getWidth() * getHeight();
    }
}
