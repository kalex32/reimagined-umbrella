package DZ1_Inheritance;

class Student extends Man {
    private int term;

    Student(String sex) {
        super(sex);
    }

    void setTerm(int term) {
        this.term = term;
    }

    void changeTerm(int newTerm) {
        this.term = newTerm;
    }
}
