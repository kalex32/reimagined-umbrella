public class Car {
    private int id; // Порядковый номер
    private String mark; //  Марка автомобиля
    private String model; // Модель
    private int year; // Год выпуска
    private String color; // Цвет
    private double price; // Текущая стоимость
    private String reg; // Гос. номер


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getReg() {
        return reg;
    }

    public void setReg(String reg) {
        this.reg = reg;
    }

    @Override
    public String toString() {
        return "Car{" +
                "id=" + id +
                ", mark='" + mark + '\'' +
                ", model='" + model + '\'' +
                ", year=" + year +
                ", color='" + color + '\'' +
                ", price=" + price +
                ", reg='" + reg + '\'' +
                '}';
    }
    public Car(int id, String mark, String model, int year, String color, double price, String reg){
        this.id=id;
        this.mark=mark;
        this.model=model;
        this.year=year;
        this.color=color;
        this.price=price;
        this.reg=reg;
    }

    public static void main(String[] args) {

        Car vehicle1 = new Car(1, "Skoda", "Octavia", 2007, "Silver", 120000, "AA3539CO");
        Car vehicle2 = new Car(2, "Renault", "Kangoo", 2012,"White",146000, "AA9430EA");
        Car vehicle3 = new Car(3, "Ford","Focus", 2013,"White", 138000, "AE4357EK");
        Car vehicle4 = new Car(4, "Volkswagen","Passat",2004,"Green", 87000,"AE1324HE");
        Car vehicle5 = new Car(5,"Ford","Fiesta",2006, "Red",79000, "AM2894HP");
        Car vehicle6 = new Car(6,"Mazda","CX5",2015, "Dark Grey",258000, "AC7633BK");
        Car vehicle7 = new Car(7,"Toyota","Land Cruiser Prado 150",2015, "Black",450000, "HE0880HE");
        Car vehicle8 = new Car(8,"Skoda","SuperB",2012, "Silver",210000, "KB5244MO");
        Car vehicle9 = new Car(9,"Audi","A5",2010, "Red",325000, "OA1864CA");
        Car vehicle10 = new Car(10,"Mitsubishi","L200",2009, "Grey",199000, "AE0987KE");

    }
}
