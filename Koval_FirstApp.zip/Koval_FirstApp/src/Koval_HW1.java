public class Koval_HW1 {
   /*
    int i=1;
    long l=775673245;
    char c='c';
    float f=1.5f;
    double d=129748756628682.2;
    boolean b=true;
    byte a=2;
    short s=45;
   */

    public static void main(String[] args) {
        double x = 1234, y = -897, a, b, c, d, e, f;
        a = x + y;
        b = x - y;
        c = x * y;
        d = x / y;
        e = x * x;
        f = y * y;
        System.out.println("Сумма = " + a);
        System.out.println("Разница = " + b);
        System.out.println("Умножение = " + c);
        System.out.println("Деление = " + d);
        System.out.println("Квадрат x = " + e +"; Квадрат y = " + f);
    }
}
